<body>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <body>
        <section>
            <div class="container">
                        <h4 class="section-title">Rekap Data</h4>
  <ul class="nav nav-tabs">
    <li class="active"><a href="#">Profile</a></li>
    <li><?php echo anchor('user/ikm_produk', 'Data Produk') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'Data Penjualan') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'Data Bahan Baku') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'Data Bahan Bakar') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'Data Mesin dan Lainnya') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'Permasalahan') ?></li>
    <li><?php echo anchor('user/ikm_produk', 'File Pendukung') ?></li>
  </ul>
  <br>
            </div>
        </section>

                    </html> 
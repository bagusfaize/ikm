<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>IKM Disperindag Riau</title>

  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="Description" content="IKM DISPERINDAG PROPINSI KEPULAUAN RIAU">
  <meta name="Keywords" content="IKM KEPRI,Kepri,Disperindag,Kepulauan Riau">
    
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>frontend/frontendSyle/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>frontend/frontendSyle/slick-theme.min.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>frontend/frontendSyle/slick.min.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo ASSET_PATH; ?>frontend/font-awesome/css/font-awesome.min.css"/>

    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>frontend/frontendSyle/styles.css" />
  </head>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>IKM Disperindag Riau</title>

    <link
      rel="stylesheet"
      type="text/css"
      href="<?php echo ASSET_PATH; ?>backend/font-awesome/css/font-awesome.min.css"
    />

    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/slick-theme.min.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/slick.min.css" />
	
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/styles.css" />
	<link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/backendStyle.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/backendSyle/RMM.css" />
	
	<!--<link href="<?php echo ASSET_PATH; ?>backend/backendSyle/bootstrap.min.css" rel="stylesheet">-->
  </head>

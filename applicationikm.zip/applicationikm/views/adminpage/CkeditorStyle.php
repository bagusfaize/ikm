<script src="<?php echo ASSET_PATH; ?>backend/ckeditor/ckeditor.js"></script>
<script src="<?php echo ASSET_PATH; ?>backend/ckeditor/sample.js"></script>
<link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/ckeditor/samples.css">
<link rel="stylesheet" href="<?php echo ASSET_PATH; ?>backend/ckeditor/neo.css">

    <footer>
      <div class="copyright">
        <p class="mb-2">
          Dinas Perindustrian dan Perdagangan Provinsi Kepulauan Riau
        </p>
        <p>Copyright © 2017 Bidang Industri Kecil dan Menengah</p>
      </div>
    </footer>
	
	<!--Bootstrap Script-->
	<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/jquery-3.3.1.slim.min.js"></script>
	<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/popper.min.js"></script>
	<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/slick.min.js"></script>
	
	<!--Backend Script-->
	<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/bootstrap-datepicker.js"></script>
	<!--<script type="text/javascript" src="<?php echo ASSET_PATH; ?>backend/backendScript/BackendScript.js"></script>-->
	<!--<script type="text/javascript">
		$('.datepicker').datepicker({
		format: 'mm/dd/yyyy'
		});
	</script>
	<script type="text/javascript">
	var sorter = new TINY.table.sorter('sorter','table',{
		headclass:'head',
		ascclass:'asc',
		descclass:'desc',
		evenclass:'evenrow',
		oddclass:'oddrow',
		evenselclass:'evenselected',
		oddselclass:'oddselected',
		paginate:true,
		size:10,
		colddid:'columns',
		currentid:'currentpage',
		totalid:'totalpages',
		startingrecid:'startrecord',
		endingrecid:'endrecord',
		totalrecid:'totalrecords',
		hoverid:'selectedrow',
		pageddid:'pagedropdown',
		navid:'tablenav',
		sortcolumn:1,
		sortdir:1,
		//sum:[8],
		//avg:[6,7,8,9],
		//columns:[{index:7, format:'%', decimals:1},{index:8, format:'$', decimals:0}],
		init:true
	});
  </script>-->
<script>
	initSample();
</script>
